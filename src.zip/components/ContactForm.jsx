import React from "react";
import { FaUser, FaEnvelope, FaCommentDots, FaPaperPlane } from "react-icons/fa";

const ContactForm = () => {
  return (
    <form className="contact-form">
      <div>
        <label>
          <FaUser style={{ marginRight: "6px" }} />
          이름:
        </label>
        <input type="text" />
      </div>
      <div>
        <label>
          <FaEnvelope style={{ marginRight: "6px" }} />
          이메일:
        </label>
        <input type="email" />
      </div>
      <div>
        <label>
          <FaCommentDots style={{ marginRight: "6px" }} />
          메시지:
        </label>
        <textarea></textarea>
      </div>
      <button type="submit">
        <FaPaperPlane style={{ marginRight: "6px" }} />
        보내기
      </button>
    </form>
  );
};

export default ContactForm;